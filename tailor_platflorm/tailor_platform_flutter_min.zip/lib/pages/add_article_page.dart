//import 'dart:ffi';

import 'package:flutter/material.dart';
import 'package:tailor_platflorm/data/mock_data.dart';
import 'package:tailor_platflorm/models/realisation.dart';



class AddArticlePage extends StatefulWidget{
  const AddArticlePage({super.key});

  @override
  State<AddArticlePage> createState () => _AddArticlePage();

}

class _AddArticlePage extends State<AddArticlePage> {

  final nomController = TextEditingController();
  final desController = TextEditingController();
  final prixController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Ajouter un article'),
      ),
      body: 
        Padding(
          padding: EdgeInsets.all(16),
          child: 
            Column(
              children: [
                TextField(
                  controller: nomController,
                  decoration: const InputDecoration(
                    labelText: 'Nom du modele',
                    hintText: 'Ex: Costume homme',
                    border: OutlineInputBorder()
                  ),
                ),
                TextField(
                  controller: desController,
                  decoration: const InputDecoration(
                    labelText: 'Description',
                    hintText: 'Un modele unique',
                    border: OutlineInputBorder()
                  ),
                ),
                const SizedBox(height: 15,),
                TextField(
                  controller: prixController,
                  decoration: const InputDecoration(
                    labelText: 'Prix du modele',
                    hintText: '5\$',
                    border: OutlineInputBorder()
                  ),
                ),
                const SizedBox(height: 20,),
                ElevatedButton(
                  onPressed: () {
                    mockRealisations.add(Realisation(title: nomController.text, description: desController.text, price: double.parse(prixController.text)));
                    print('la valeur saisie dans le champ du modele est: ${nomController.text}, description: ${desController.text}, prix: ${double.parse(prixController.text)}');
                    Navigator.pop(context);
                  }, 
                  child: Text('Ajouter')
                )
              ],
            ),
        ),
    );
  }

}
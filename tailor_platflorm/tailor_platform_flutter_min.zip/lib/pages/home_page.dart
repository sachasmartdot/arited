import 'package:firebase_auth/firebase_auth.dart';
//import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:tailor_platflorm/pages/client_catalogue_page.dart';
import 'package:tailor_platflorm/pages/tailor_profile_page.dart';

class HomePage extends StatelessWidget{

  const HomePage({super.key});

  Future<void> testerAuth() async {
    try {
      final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: 'sacha@arited.com', 
        password: 'password',
      );
      print('Compte created : ${credential.user?.uid}');
    } 
    on FirebaseAuthException catch (e) {
      print('Erreur : ${e.code} - ${e.message}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Accueil Tailor pour le test'),
      ),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [

            ElevatedButton(
              onPressed: () => Navigator.push(
                context, 
                MaterialPageRoute(builder: (context) => const ClientCataloguePage())
              ),
              child: Text('Client'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.push(
                context, 
                MaterialPageRoute(builder: (context) => const TailorProfilePage())
              ),
              child: Text('Tailleur'),
            ),
            ElevatedButton(
              onPressed: () {
                testerAuth();
              },
              child: Text('verifier firebase.. ok'),
            )
          
          ],
        ),
      ),

    );
  }

}